#include <stdio.h>
#include <string.h>
int main(){
	int *new = 10;
	printf("%d",a[0]);
}